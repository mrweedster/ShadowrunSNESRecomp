/* Auto-generated from the authoritative LLE/AOT manifest. */
#include "cpu_state.h"

RecompReturn I_RESET_M1X1(CpuState *cpu);
RecompReturn I_IRQ_M0X0(CpuState *cpu);
RecompReturn I_IRQ_M0X1(CpuState *cpu);
RecompReturn I_IRQ_M1X0(CpuState *cpu);
RecompReturn I_IRQ_M1X1(CpuState *cpu);
RecompReturn bank_80_80B2_M0X0(CpuState *cpu);
RecompReturn bank_80_8133_M0X0(CpuState *cpu);
RecompReturn bank_80_81B4_M0X0(CpuState *cpu);
RecompReturn bank_80_8220_M0X0(CpuState *cpu);
RecompReturn bank_80_8238_M0X0(CpuState *cpu);
RecompReturn bank_80_82BC_M0X0(CpuState *cpu);
RecompReturn bank_80_8371_M0X0(CpuState *cpu);
RecompReturn bank_80_8486_M0X0(CpuState *cpu);
RecompReturn bank_80_8497_M0X0(CpuState *cpu);
RecompReturn bank_80_8511_M0X0(CpuState *cpu);
RecompReturn bank_80_8521_M0X0(CpuState *cpu);
RecompReturn bank_80_866F_M0X0(CpuState *cpu);
RecompReturn bank_80_8A43_M0X0(CpuState *cpu);
RecompReturn bank_80_8BC5_M0X0(CpuState *cpu);
RecompReturn bank_80_8EF5_M0X0(CpuState *cpu);
RecompReturn bank_80_8EFE_M0X0(CpuState *cpu);
RecompReturn bank_80_8F20_M0X0(CpuState *cpu);
RecompReturn bank_80_8F3A_M0X0(CpuState *cpu);
RecompReturn bank_80_8F97_M0X0(CpuState *cpu);
RecompReturn bank_80_8FB3_M0X0(CpuState *cpu);
RecompReturn bank_80_8FF5_M0X0(CpuState *cpu);
RecompReturn bank_80_9022_M0X0(CpuState *cpu);
RecompReturn bank_80_905E_M0X0(CpuState *cpu);
RecompReturn bank_80_908C_M1X0(CpuState *cpu);
RecompReturn bank_80_9471_M0X0(CpuState *cpu);
RecompReturn bank_80_9590_M0X0(CpuState *cpu);
RecompReturn bank_80_95AC_M0X0(CpuState *cpu);
RecompReturn bank_80_986C_M0X0(CpuState *cpu);
RecompReturn bank_80_9CFD_M0X0(CpuState *cpu);
RecompReturn bank_80_9D1B_M0X0(CpuState *cpu);
RecompReturn bank_80_9D9D_M0X0(CpuState *cpu);
RecompReturn bank_80_9DE8_M0X0(CpuState *cpu);
RecompReturn bank_80_9E01_M0X0(CpuState *cpu);
RecompReturn bank_80_9E1E_M0X0(CpuState *cpu);
RecompReturn bank_80_9ECC_M0X0(CpuState *cpu);
RecompReturn bank_80_9ED0_M0X0(CpuState *cpu);
RecompReturn bank_80_9EEC_M0X0(CpuState *cpu);
RecompReturn bank_80_9EF0_M0X0(CpuState *cpu);
RecompReturn bank_80_A0DF_M0X0(CpuState *cpu);
RecompReturn bank_80_A173_M0X0(CpuState *cpu);
RecompReturn bank_80_A287_M0X0(CpuState *cpu);
RecompReturn bank_80_A343_M0X0(CpuState *cpu);
RecompReturn bank_80_A3DA_M0X0(CpuState *cpu);
RecompReturn bank_80_A3F1_M0X0(CpuState *cpu);
RecompReturn bank_80_A44C_M0X0(CpuState *cpu);
RecompReturn CC_80A568_M0X0(CpuState *cpu);
RecompReturn bank_80_A586_M0X0(CpuState *cpu);
RecompReturn bank_80_A5A4_M0X0(CpuState *cpu);
RecompReturn bank_80_A7C2_M0X0(CpuState *cpu);
RecompReturn bank_80_A882_M0X0(CpuState *cpu);
RecompReturn bank_80_A8AA_M0X0(CpuState *cpu);
RecompReturn bank_80_A8BC_M0X0(CpuState *cpu);
RecompReturn bank_80_A8E6_M0X0(CpuState *cpu);
RecompReturn bank_80_A8F0_M0X0(CpuState *cpu);
RecompReturn bank_80_A8FA_M0X0(CpuState *cpu);
RecompReturn bank_80_A912_M0X0(CpuState *cpu);
RecompReturn bank_80_A9D9_M0X0(CpuState *cpu);
RecompReturn bank_80_AA0A_M0X0(CpuState *cpu);
RecompReturn bank_80_AA3C_M0X0(CpuState *cpu);
RecompReturn bank_80_AAA9_M0X0(CpuState *cpu);
RecompReturn bank_80_AAA9_M1X1(CpuState *cpu);
RecompReturn GS_80AAB3_M0X0(CpuState *cpu);
RecompReturn bank_80_ABBC_M0X0(CpuState *cpu);
RecompReturn bank_80_AD81_M0X0(CpuState *cpu);
RecompReturn bank_80_AD9F_M0X0(CpuState *cpu);
RecompReturn bank_80_B03C_M0X0(CpuState *cpu);
RecompReturn bank_80_B047_M0X0(CpuState *cpu);
RecompReturn bank_80_B052_M0X0(CpuState *cpu);
RecompReturn bank_80_B05D_M0X0(CpuState *cpu);
RecompReturn bank_80_B07F_M0X0(CpuState *cpu);
RecompReturn bank_80_B07F_M1X1(CpuState *cpu);
RecompReturn bank_80_B08A_M0X0(CpuState *cpu);
RecompReturn bank_80_B08A_M1X1(CpuState *cpu);
RecompReturn bank_80_B095_M0X0(CpuState *cpu);
RecompReturn bank_80_B095_M1X1(CpuState *cpu);
RecompReturn bank_80_B0A0_M0X0(CpuState *cpu);
RecompReturn bank_80_B0A0_M1X1(CpuState *cpu);
RecompReturn bank_80_B101_M0X0(CpuState *cpu);
RecompReturn bank_80_B37C_M0X0(CpuState *cpu);
RecompReturn FR_80B800_M1X1(CpuState *cpu);
RecompReturn bank_80_BA8B_M0X0(CpuState *cpu);
RecompReturn bank_80_BBEA_M0X0(CpuState *cpu);
RecompReturn bank_80_BC06_M0X0(CpuState *cpu);
RecompReturn bank_80_BC37_M0X0(CpuState *cpu);
RecompReturn bank_80_BC50_M0X0(CpuState *cpu);
RecompReturn bank_80_BC69_M0X0(CpuState *cpu);
RecompReturn bank_80_BC82_M0X0(CpuState *cpu);
RecompReturn bank_80_BC8E_M0X0(CpuState *cpu);
RecompReturn bank_80_BD17_M0X0(CpuState *cpu);
RecompReturn CC_80BE2B_M0X0(CpuState *cpu);
RecompReturn bank_80_BE3D_M0X0(CpuState *cpu);
RecompReturn bank_80_C0D9_M0X0(CpuState *cpu);
RecompReturn bank_80_C0D9_M1X0(CpuState *cpu);
RecompReturn CC_80C11F_M0X0(CpuState *cpu);
RecompReturn bank_80_C176_M0X0(CpuState *cpu);
RecompReturn bank_80_C212_M0X0(CpuState *cpu);
RecompReturn bank_80_C298_M0X0(CpuState *cpu);
RecompReturn bank_80_C31A_M0X0(CpuState *cpu);
RecompReturn bank_80_C336_M0X0(CpuState *cpu);
RecompReturn bank_80_C33A_M0X0(CpuState *cpu);
RecompReturn GS_80C399_M0X0(CpuState *cpu);
RecompReturn bank_80_C3D1_M0X0(CpuState *cpu);
RecompReturn bank_80_C3E6_M0X0(CpuState *cpu);
RecompReturn CC_80C43E_M0X0(CpuState *cpu);
RecompReturn bank_80_C4EF_M0X0(CpuState *cpu);
RecompReturn bank_80_C530_M0X0(CpuState *cpu);
RecompReturn bank_80_C65D_M0X0(CpuState *cpu);
RecompReturn bank_80_C666_M0X0(CpuState *cpu);
RecompReturn bank_80_C68F_M0X0(CpuState *cpu);
RecompReturn bank_80_C694_M0X0(CpuState *cpu);
RecompReturn bank_80_C6E6_M0X0(CpuState *cpu);
RecompReturn bank_80_C792_M0X0(CpuState *cpu);
RecompReturn bank_80_C7DC_M0X0(CpuState *cpu);
RecompReturn FR_80C800_M1X1(CpuState *cpu);
RecompReturn bank_80_C81D_M0X0(CpuState *cpu);
RecompReturn bank_80_C8E3_M0X0(CpuState *cpu);
RecompReturn bank_80_C9B0_M0X0(CpuState *cpu);
RecompReturn bank_80_C9E5_M0X0(CpuState *cpu);
RecompReturn bank_80_C9F0_M0X0(CpuState *cpu);
RecompReturn bank_80_CA0A_M0X0(CpuState *cpu);
RecompReturn bank_80_CA19_M0X0(CpuState *cpu);
RecompReturn bank_80_CA72_M0X0(CpuState *cpu);
RecompReturn bank_80_CA84_M0X0(CpuState *cpu);
RecompReturn bank_80_CA9A_M0X0(CpuState *cpu);
RecompReturn bank_80_CAB0_M0X0(CpuState *cpu);
RecompReturn bank_80_CAFB_M0X0(CpuState *cpu);
RecompReturn bank_80_CB83_M0X0(CpuState *cpu);
RecompReturn bank_80_CBD7_M0X0(CpuState *cpu);
RecompReturn bank_80_CBE0_M0X0(CpuState *cpu);
RecompReturn bank_80_CC14_M0X0(CpuState *cpu);
RecompReturn bank_80_CD78_M0X0(CpuState *cpu);
RecompReturn bank_80_CF63_M0X0(CpuState *cpu);
RecompReturn bank_80_D0D5_M0X0(CpuState *cpu);
RecompReturn bank_80_D10E_M0X0(CpuState *cpu);
RecompReturn bank_80_D11A_M0X0(CpuState *cpu);
RecompReturn bank_80_D12C_M0X0(CpuState *cpu);
RecompReturn bank_80_D15A_M0X0(CpuState *cpu);
RecompReturn bank_80_D19A_M0X0(CpuState *cpu);
RecompReturn bank_80_D1AB_M0X0(CpuState *cpu);
RecompReturn bank_80_D21D_M0X0(CpuState *cpu);
RecompReturn bank_80_DE48_M0X0(CpuState *cpu);
RecompReturn bank_80_DE91_M0X0(CpuState *cpu);
RecompReturn bank_80_DF35_M0X0(CpuState *cpu);
RecompReturn FR_80E000_M1X1(CpuState *cpu);
RecompReturn bank_80_E218_M0X0(CpuState *cpu);
RecompReturn bank_80_E22C_M0X0(CpuState *cpu);
RecompReturn bank_80_E34C_M1X1(CpuState *cpu);
RecompReturn bank_80_E3E5_M0X0(CpuState *cpu);
RecompReturn bank_80_E3E9_M0X0(CpuState *cpu);
RecompReturn bank_80_E3FD_M0X0(CpuState *cpu);
RecompReturn bank_80_E457_M0X0(CpuState *cpu);
RecompReturn bank_80_E47D_M0X0(CpuState *cpu);
RecompReturn bank_80_E7FE_M0X0(CpuState *cpu);
RecompReturn bank_80_E892_M0X0(CpuState *cpu);
RecompReturn bank_80_E972_M0X0(CpuState *cpu);
RecompReturn bank_80_E98F_M0X0(CpuState *cpu);
RecompReturn bank_80_ED06_M0X0(CpuState *cpu);
RecompReturn bank_80_F262_M0X0(CpuState *cpu);
RecompReturn bank_80_F26A_M0X0(CpuState *cpu);
RecompReturn bank_80_F26E_M0X0(CpuState *cpu);
RecompReturn bank_80_F485_M0X0(CpuState *cpu);
RecompReturn bank_80_F488_M0X0(CpuState *cpu);
RecompReturn bank_80_F73E_M0X0(CpuState *cpu);
RecompReturn bank_80_F780_M0X0(CpuState *cpu);
RecompReturn bank_80_F7C2_M0X0(CpuState *cpu);
RecompReturn bank_80_F807_M0X0(CpuState *cpu);
RecompReturn bank_80_F8F1_M0X0(CpuState *cpu);
RecompReturn bank_80_F91D_M0X0(CpuState *cpu);
RecompReturn bank_80_F92D_M0X0(CpuState *cpu);
RecompReturn bank_80_FA08_M0X0(CpuState *cpu);
RecompReturn CC_80FA31_M0X0(CpuState *cpu);
RecompReturn CC_80FA31_M1X1(CpuState *cpu);
RecompReturn bank_80_FA5C_M0X0(CpuState *cpu);
RecompReturn bank_80_FA76_M0X0(CpuState *cpu);
RecompReturn bank_80_FA76_M1X1(CpuState *cpu);
RecompReturn bank_80_FAA7_M0X0(CpuState *cpu);
RecompReturn bank_80_FAF4_M1X0(CpuState *cpu);
RecompReturn bank_80_FB03_M0X0(CpuState *cpu);
RecompReturn bank_80_FD4A_M0X0(CpuState *cpu);
RecompReturn bank_80_FD99_M0X0(CpuState *cpu);
RecompReturn bank_80_FE33_M0X0(CpuState *cpu);
RecompReturn bank_80_FE8B_M0X0(CpuState *cpu);
RecompReturn bank_80_FF43_M0X0(CpuState *cpu);
RecompReturn bank_81_8000_M0X0(CpuState *cpu);
RecompReturn bank_81_801A_M0X0(CpuState *cpu);
RecompReturn bank_81_8076_M0X0(CpuState *cpu);
RecompReturn bank_81_83FB_M0X0(CpuState *cpu);
RecompReturn bank_81_840E_M0X0(CpuState *cpu);
RecompReturn bank_81_84CF_M0X0(CpuState *cpu);
RecompReturn bank_81_84DE_M0X0(CpuState *cpu);
RecompReturn bank_81_85FE_M0X0(CpuState *cpu);
RecompReturn bank_81_8686_M0X0(CpuState *cpu);
RecompReturn CC_8186E5_M0X0(CpuState *cpu);
RecompReturn bank_81_8701_M0X0(CpuState *cpu);
RecompReturn bank_81_8756_M0X0(CpuState *cpu);
RecompReturn bank_81_8861_M0X0(CpuState *cpu);
RecompReturn bank_81_886A_M0X0(CpuState *cpu);
RecompReturn bank_81_8877_M0X0(CpuState *cpu);
RecompReturn bank_81_891A_M0X0(CpuState *cpu);
RecompReturn bank_81_8954_M0X0(CpuState *cpu);
RecompReturn bank_81_8A05_M0X0(CpuState *cpu);
RecompReturn bank_81_8A91_M0X0(CpuState *cpu);
RecompReturn bank_81_8BD9_M0X0(CpuState *cpu);
RecompReturn bank_81_8CB9_M0X0(CpuState *cpu);
RecompReturn bank_81_8CE0_M0X0(CpuState *cpu);
RecompReturn bank_81_8D05_M0X0(CpuState *cpu);
RecompReturn bank_81_8D09_M0X0(CpuState *cpu);
RecompReturn bank_81_8D23_M0X0(CpuState *cpu);
RecompReturn bank_81_8D3D_M0X0(CpuState *cpu);
RecompReturn bank_81_8DC0_M0X0(CpuState *cpu);
RecompReturn bank_81_8DE2_M0X0(CpuState *cpu);
RecompReturn bank_81_8E57_M0X0(CpuState *cpu);
RecompReturn bank_81_8EDF_M0X0(CpuState *cpu);
RecompReturn bank_81_8FC2_M0X0(CpuState *cpu);
RecompReturn bank_81_8FF0_M0X0(CpuState *cpu);
RecompReturn bank_81_9022_M0X0(CpuState *cpu);
RecompReturn bank_81_902D_M0X0(CpuState *cpu);
RecompReturn bank_81_903E_M0X0(CpuState *cpu);
RecompReturn bank_81_940A_M0X0(CpuState *cpu);
RecompReturn bank_81_9490_M0X0(CpuState *cpu);
RecompReturn bank_81_9AE6_M0X0(CpuState *cpu);
RecompReturn bank_81_A117_M0X0(CpuState *cpu);
RecompReturn bank_81_A1BC_M0X0(CpuState *cpu);
RecompReturn bank_81_A1E1_M0X0(CpuState *cpu);
RecompReturn bank_81_A243_M0X0(CpuState *cpu);
RecompReturn bank_81_A25F_M0X0(CpuState *cpu);
RecompReturn bank_81_A32D_M0X0(CpuState *cpu);
RecompReturn bank_81_A344_M0X0(CpuState *cpu);
RecompReturn bank_81_A55C_M0X0(CpuState *cpu);
RecompReturn bank_81_A772_M0X0(CpuState *cpu);
RecompReturn bank_81_A7FC_M0X0(CpuState *cpu);
RecompReturn bank_81_A910_M0X0(CpuState *cpu);
RecompReturn bank_81_A96E_M0X0(CpuState *cpu);
RecompReturn bank_81_A99D_M0X0(CpuState *cpu);
RecompReturn bank_81_AA58_M0X0(CpuState *cpu);
RecompReturn bank_81_AAE8_M0X0(CpuState *cpu);
RecompReturn bank_81_AC6B_M0X0(CpuState *cpu);
RecompReturn bank_81_AC71_M0X0(CpuState *cpu);
RecompReturn bank_81_AC79_M0X0(CpuState *cpu);
RecompReturn bank_81_AC79_M1X1(CpuState *cpu);
RecompReturn bank_81_AC7F_M0X0(CpuState *cpu);
RecompReturn bank_81_AC85_M0X0(CpuState *cpu);
RecompReturn bank_81_AC8B_M0X0(CpuState *cpu);
RecompReturn bank_81_AD4E_M0X0(CpuState *cpu);
RecompReturn bank_81_AD76_M0X0(CpuState *cpu);
RecompReturn bank_81_ADD0_M0X0(CpuState *cpu);
RecompReturn bank_81_AE08_M0X0(CpuState *cpu);
RecompReturn bank_81_AE09_M0X0(CpuState *cpu);
RecompReturn bank_81_AE84_M0X0(CpuState *cpu);
RecompReturn bank_81_AEB0_M0X0(CpuState *cpu);
RecompReturn bank_81_AEB8_M0X0(CpuState *cpu);
RecompReturn bank_81_AEC0_M0X0(CpuState *cpu);
RecompReturn bank_81_AEDB_M0X0(CpuState *cpu);
RecompReturn bank_81_B020_M0X0(CpuState *cpu);
RecompReturn CC_81B05D_M0X0(CpuState *cpu);
RecompReturn CC_81B05D_M1X1(CpuState *cpu);
RecompReturn bank_81_B068_M0X0(CpuState *cpu);
RecompReturn bank_81_B079_M0X0(CpuState *cpu);
RecompReturn bank_81_B0D6_M0X0(CpuState *cpu);
RecompReturn bank_81_B0E8_M0X0(CpuState *cpu);
RecompReturn bank_81_B130_M1X0(CpuState *cpu);
RecompReturn bank_81_B167_M0X0(CpuState *cpu);
RecompReturn bank_81_D4EE_M0X0(CpuState *cpu);
RecompReturn bank_81_D512_M0X0(CpuState *cpu);
RecompReturn bank_81_D58D_M1X0(CpuState *cpu);
RecompReturn bank_81_D5A1_M1X0(CpuState *cpu);
RecompReturn bank_81_D5A9_M1X0(CpuState *cpu);
RecompReturn bank_81_D5B1_M1X0(CpuState *cpu);
RecompReturn bank_81_D5CC_M0X0(CpuState *cpu);
RecompReturn bank_81_D5FF_M0X0(CpuState *cpu);
RecompReturn bank_81_D651_M0X0(CpuState *cpu);
RecompReturn bank_81_D7DC_M0X0(CpuState *cpu);
RecompReturn bank_81_D7FB_M0X0(CpuState *cpu);
RecompReturn bank_81_D839_M0X0(CpuState *cpu);
RecompReturn bank_81_D8A2_M0X0(CpuState *cpu);
RecompReturn bank_81_D8E4_M0X0(CpuState *cpu);
RecompReturn bank_81_DC00_M0X0(CpuState *cpu);
RecompReturn bank_81_DD6E_M0X0(CpuState *cpu);
RecompReturn bank_81_DD9C_M0X0(CpuState *cpu);
RecompReturn bank_81_DE54_M0X0(CpuState *cpu);
RecompReturn bank_81_E10B_M0X0(CpuState *cpu);
RecompReturn bank_81_E260_M0X0(CpuState *cpu);
RecompReturn bank_81_E2F0_M0X0(CpuState *cpu);
RecompReturn bank_81_E304_M0X0(CpuState *cpu);
RecompReturn bank_81_E315_M0X0(CpuState *cpu);
RecompReturn bank_81_E332_M0X0(CpuState *cpu);
RecompReturn bank_81_E34E_M0X0(CpuState *cpu);
RecompReturn bank_81_E39B_M0X0(CpuState *cpu);
RecompReturn bank_81_E407_M0X0(CpuState *cpu);
RecompReturn bank_81_E4CD_M0X0(CpuState *cpu);
RecompReturn bank_81_E53F_M0X0(CpuState *cpu);
RecompReturn bank_81_E59C_M0X0(CpuState *cpu);
RecompReturn bank_81_E5E4_M0X0(CpuState *cpu);
RecompReturn bank_81_E645_M0X0(CpuState *cpu);
RecompReturn bank_81_E65A_M0X0(CpuState *cpu);
RecompReturn bank_81_E77D_M0X0(CpuState *cpu);
RecompReturn bank_81_E8A6_M0X0(CpuState *cpu);
RecompReturn bank_81_EB3C_M0X0(CpuState *cpu);
RecompReturn bank_81_EB4A_M0X0(CpuState *cpu);
RecompReturn bank_81_EB4A_M1X0(CpuState *cpu);
RecompReturn bank_81_EB58_M0X0(CpuState *cpu);
RecompReturn bank_81_EBAA_M0X0(CpuState *cpu);
RecompReturn bank_81_EBD7_M0X0(CpuState *cpu);
RecompReturn bank_81_EC02_M0X0(CpuState *cpu);
RecompReturn bank_81_EC03_M0X0(CpuState *cpu);
RecompReturn bank_81_EC10_M0X0(CpuState *cpu);
RecompReturn bank_81_EC29_M0X0(CpuState *cpu);
RecompReturn bank_81_EC78_M0X0(CpuState *cpu);
RecompReturn bank_81_EC8F_M0X0(CpuState *cpu);
RecompReturn bank_81_EC90_M0X0(CpuState *cpu);
RecompReturn bank_81_EC91_M0X0(CpuState *cpu);
RecompReturn bank_81_ECB3_M0X0(CpuState *cpu);
RecompReturn bank_81_ED4C_M1X0(CpuState *cpu);
RecompReturn bank_81_ED77_M1X0(CpuState *cpu);
RecompReturn bank_81_EDE3_M1X0(CpuState *cpu);
RecompReturn bank_81_EE10_M1X0(CpuState *cpu);
RecompReturn bank_81_EE7C_M0X0(CpuState *cpu);
RecompReturn bank_81_EE7C_M1X1(CpuState *cpu);
RecompReturn bank_81_EE96_M0X0(CpuState *cpu);
RecompReturn bank_81_EE9E_M0X0(CpuState *cpu);
RecompReturn bank_81_EEB2_M0X0(CpuState *cpu);
RecompReturn bank_81_EEC8_M0X0(CpuState *cpu);
RecompReturn bank_81_EEE7_M0X0(CpuState *cpu);
RecompReturn bank_81_EEF7_M0X0(CpuState *cpu);
RecompReturn bank_81_EF08_M0X0(CpuState *cpu);
RecompReturn bank_81_EF24_M0X0(CpuState *cpu);
RecompReturn bank_81_EF55_M0X0(CpuState *cpu);
RecompReturn bank_81_EF66_M1X0(CpuState *cpu);
RecompReturn bank_81_EFBB_M1X0(CpuState *cpu);
RecompReturn bank_81_EFC2_M1X0(CpuState *cpu);
RecompReturn bank_81_EFC8_M0X0(CpuState *cpu);
RecompReturn bank_81_EFC8_M1X0(CpuState *cpu);
RecompReturn bank_81_EFFB_M1X0(CpuState *cpu);
RecompReturn bank_81_F040_M0X0(CpuState *cpu);
RecompReturn bank_81_F053_M0X0(CpuState *cpu);
RecompReturn bank_81_F0C1_M0X0(CpuState *cpu);
RecompReturn bank_81_F0E3_M0X0(CpuState *cpu);
RecompReturn bank_81_F0F1_M0X0(CpuState *cpu);
RecompReturn bank_81_F1A9_M0X0(CpuState *cpu);
RecompReturn bank_81_F1BB_M1X0(CpuState *cpu);
RecompReturn bank_81_F1EA_M0X0(CpuState *cpu);
RecompReturn bank_81_F21B_M0X0(CpuState *cpu);
RecompReturn bank_81_F250_M0X0(CpuState *cpu);
RecompReturn bank_81_F267_M0X0(CpuState *cpu);

const DispatchEntry g_dispatch_table[] = {
    { 0x00C0E2u, { NULL, NULL, NULL, NULL }, 0 },  /* I_NMI */
    { 0x00E34Cu, { NULL, NULL, NULL, I_RESET_M1X1 }, 0 },  /* I_RESET */
    { 0x00F27Du, { I_IRQ_M0X0, I_IRQ_M0X1, I_IRQ_M1X0, I_IRQ_M1X1 }, 0 },  /* I_IRQ */
    { 0x808000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808000 */
    { 0x8080B2u, { bank_80_80B2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_80B2 */
    { 0x808133u, { bank_80_8133_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8133 */
    { 0x8081B4u, { bank_80_81B4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_81B4 */
    { 0x808200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808200 */
    { 0x808220u, { bank_80_8220_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8220 */
    { 0x808238u, { bank_80_8238_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8238 */
    { 0x8082BCu, { bank_80_82BC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_82BC */
    { 0x808371u, { bank_80_8371_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8371 */
    { 0x808486u, { bank_80_8486_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8486 */
    { 0x808497u, { bank_80_8497_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8497 */
    { 0x808511u, { bank_80_8511_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8511 */
    { 0x808521u, { bank_80_8521_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8521 */
    { 0x808600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808600 */
    { 0x80866Fu, { bank_80_866F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_866F */
    { 0x808691u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8691 */
    { 0x808800u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808800 */
    { 0x80881Cu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_881C */
    { 0x808904u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8904 */
    { 0x808A00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808A00 */
    { 0x808A43u, { bank_80_8A43_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8A43 */
    { 0x808AB5u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8AB5 */
    { 0x808BC5u, { bank_80_8BC5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8BC5 */
    { 0x808EF5u, { bank_80_8EF5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8EF5 */
    { 0x808EFEu, { bank_80_8EFE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8EFE */
    { 0x808F20u, { bank_80_8F20_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8F20 */
    { 0x808F3Au, { bank_80_8F3A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8F3A */
    { 0x808F97u, { bank_80_8F97_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8F97 */
    { 0x808FAAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8FAA */
    { 0x808FB3u, { bank_80_8FB3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8FB3 */
    { 0x808FF5u, { bank_80_8FF5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8FF5 */
    { 0x809000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809000 */
    { 0x809022u, { bank_80_9022_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9022 */
    { 0x80905Eu, { bank_80_905E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_905E */
    { 0x80908Cu, { NULL, NULL, bank_80_908C_M1X0, NULL }, 0 },  /* bank_80_908C */
    { 0x809123u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_9123 */
    { 0x809200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809200 */
    { 0x809248u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_9248 */
    { 0x8092EFu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_92EF */
    { 0x809471u, { bank_80_9471_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9471 */
    { 0x809590u, { bank_80_9590_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9590 */
    { 0x8095ACu, { bank_80_95AC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_95AC */
    { 0x80961Cu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80961C */
    { 0x809676u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_809676 */
    { 0x80986Cu, { bank_80_986C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_986C */
    { 0x80996Eu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80996E */
    { 0x809CFDu, { bank_80_9CFD_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9CFD */
    { 0x809D1Bu, { bank_80_9D1B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9D1B */
    { 0x809D9Du, { bank_80_9D9D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9D9D */
    { 0x809DE8u, { bank_80_9DE8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9DE8 */
    { 0x809E01u, { bank_80_9E01_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9E01 */
    { 0x809E1Eu, { bank_80_9E1E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9E1E */
    { 0x809ECCu, { bank_80_9ECC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9ECC */
    { 0x809ED0u, { bank_80_9ED0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9ED0 */
    { 0x809EECu, { bank_80_9EEC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9EEC */
    { 0x809EF0u, { bank_80_9EF0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9EF0 */
    { 0x80A0B6u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_A0B6 */
    { 0x80A0DFu, { bank_80_A0DF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A0DF */
    { 0x80A0EBu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A0EB */
    { 0x80A113u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A113 */
    { 0x80A173u, { bank_80_A173_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A173 */
    { 0x80A287u, { bank_80_A287_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A287 */
    { 0x80A343u, { bank_80_A343_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A343 */
    { 0x80A3DAu, { bank_80_A3DA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A3DA */
    { 0x80A3F1u, { bank_80_A3F1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A3F1 */
    { 0x80A44Cu, { bank_80_A44C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A44C */
    { 0x80A568u, { CC_80A568_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80A568 */
    { 0x80A586u, { bank_80_A586_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A586 */
    { 0x80A5A4u, { bank_80_A5A4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A5A4 */
    { 0x80A632u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A632 */
    { 0x80A63Au, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_A63A */
    { 0x80A654u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_A654 */
    { 0x80A6B0u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_A6B0 */
    { 0x80A7C2u, { bank_80_A7C2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A7C2 */
    { 0x80A882u, { bank_80_A882_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A882 */
    { 0x80A8AAu, { bank_80_A8AA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A8AA */
    { 0x80A8BCu, { bank_80_A8BC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A8BC */
    { 0x80A8E6u, { bank_80_A8E6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A8E6 */
    { 0x80A8F0u, { bank_80_A8F0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A8F0 */
    { 0x80A8FAu, { bank_80_A8FA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A8FA */
    { 0x80A912u, { bank_80_A912_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A912 */
    { 0x80A9D9u, { bank_80_A9D9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A9D9 */
    { 0x80AA0Au, { bank_80_AA0A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_AA0A */
    { 0x80AA3Cu, { bank_80_AA3C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_AA3C */
    { 0x80AAA9u, { bank_80_AAA9_M0X0, NULL, NULL, bank_80_AAA9_M1X1 }, 0 },  /* bank_80_AAA9 */
    { 0x80AAB3u, { GS_80AAB3_M0X0, NULL, NULL, NULL }, 0 },  /* GS_80AAB3 */
    { 0x80ABBCu, { bank_80_ABBC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_ABBC */
    { 0x80AC00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AC00 */
    { 0x80AD81u, { bank_80_AD81_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_AD81 */
    { 0x80AD9Fu, { bank_80_AD9F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_AD9F */
    { 0x80AE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AE00 */
    { 0x80AF89u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_AF89 */
    { 0x80B000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B000 */
    { 0x80B032u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B032 */
    { 0x80B03Cu, { bank_80_B03C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B03C */
    { 0x80B047u, { bank_80_B047_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B047 */
    { 0x80B052u, { bank_80_B052_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B052 */
    { 0x80B05Du, { bank_80_B05D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B05D */
    { 0x80B07Au, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80B07A */
    { 0x80B07Fu, { bank_80_B07F_M0X0, NULL, NULL, bank_80_B07F_M1X1 }, 0 },  /* bank_80_B07F */
    { 0x80B08Au, { bank_80_B08A_M0X0, NULL, NULL, bank_80_B08A_M1X1 }, 0 },  /* bank_80_B08A */
    { 0x80B095u, { bank_80_B095_M0X0, NULL, NULL, bank_80_B095_M1X1 }, 0 },  /* bank_80_B095 */
    { 0x80B0A0u, { bank_80_B0A0_M0X0, NULL, NULL, bank_80_B0A0_M1X1 }, 0 },  /* bank_80_B0A0 */
    { 0x80B101u, { bank_80_B101_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B101 */
    { 0x80B200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B200 */
    { 0x80B37Cu, { bank_80_B37C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_B37C */
    { 0x80B400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B400 */
    { 0x80B600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B600 */
    { 0x80B800u, { NULL, NULL, NULL, FR_80B800_M1X1 }, 0 },  /* FR_80B800 */
    { 0x80B8AFu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B8AF */
    { 0x80BA8Bu, { bank_80_BA8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BA8B */
    { 0x80BBEAu, { bank_80_BBEA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BBEA */
    { 0x80BC06u, { bank_80_BC06_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC06 */
    { 0x80BC37u, { bank_80_BC37_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC37 */
    { 0x80BC50u, { bank_80_BC50_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC50 */
    { 0x80BC69u, { bank_80_BC69_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC69 */
    { 0x80BC82u, { bank_80_BC82_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC82 */
    { 0x80BC8Eu, { bank_80_BC8E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC8E */
    { 0x80BD17u, { bank_80_BD17_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BD17 */
    { 0x80BE2Bu, { CC_80BE2B_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80BE2B */
    { 0x80BE3Du, { bank_80_BE3D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BE3D */
    { 0x80BF0Bu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80BF0B */
    { 0x80C0D9u, { bank_80_C0D9_M0X0, NULL, bank_80_C0D9_M1X0, NULL }, 0 },  /* bank_80_C0D9 */
    { 0x80C11Fu, { CC_80C11F_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80C11F */
    { 0x80C176u, { bank_80_C176_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C176 */
    { 0x80C19Au, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_C19A */
    { 0x80C1C9u, { NULL, NULL, NULL, NULL }, 0 },  /* GS_80C1C9 */
    { 0x80C212u, { bank_80_C212_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C212 */
    { 0x80C298u, { bank_80_C298_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C298 */
    { 0x80C31Au, { bank_80_C31A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C31A */
    { 0x80C336u, { bank_80_C336_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C336 */
    { 0x80C33Au, { bank_80_C33A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C33A */
    { 0x80C399u, { GS_80C399_M0X0, NULL, NULL, NULL }, 0 },  /* GS_80C399 */
    { 0x80C3D1u, { bank_80_C3D1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C3D1 */
    { 0x80C3E6u, { bank_80_C3E6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C3E6 */
    { 0x80C43Eu, { CC_80C43E_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80C43E */
    { 0x80C4EFu, { bank_80_C4EF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C4EF */
    { 0x80C530u, { bank_80_C530_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C530 */
    { 0x80C600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80C600 */
    { 0x80C65Du, { bank_80_C65D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C65D */
    { 0x80C666u, { bank_80_C666_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C666 */
    { 0x80C68Fu, { bank_80_C68F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C68F */
    { 0x80C694u, { bank_80_C694_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C694 */
    { 0x80C6E6u, { bank_80_C6E6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C6E6 */
    { 0x80C792u, { bank_80_C792_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C792 */
    { 0x80C7DCu, { bank_80_C7DC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C7DC */
    { 0x80C800u, { NULL, NULL, NULL, FR_80C800_M1X1 }, 0 },  /* FR_80C800 */
    { 0x80C81Du, { bank_80_C81D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C81D */
    { 0x80C8E3u, { bank_80_C8E3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C8E3 */
    { 0x80C9B0u, { bank_80_C9B0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C9B0 */
    { 0x80C9E5u, { bank_80_C9E5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C9E5 */
    { 0x80C9F0u, { bank_80_C9F0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C9F0 */
    { 0x80CA00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CA00 */
    { 0x80CA0Au, { bank_80_CA0A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CA0A */
    { 0x80CA19u, { bank_80_CA19_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CA19 */
    { 0x80CA72u, { bank_80_CA72_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CA72 */
    { 0x80CA84u, { bank_80_CA84_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CA84 */
    { 0x80CA9Au, { bank_80_CA9A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CA9A */
    { 0x80CAB0u, { bank_80_CAB0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CAB0 */
    { 0x80CAFBu, { bank_80_CAFB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CAFB */
    { 0x80CB83u, { bank_80_CB83_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CB83 */
    { 0x80CBD7u, { bank_80_CBD7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CBD7 */
    { 0x80CBE0u, { bank_80_CBE0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CBE0 */
    { 0x80CC14u, { bank_80_CC14_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CC14 */
    { 0x80CD78u, { bank_80_CD78_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CD78 */
    { 0x80CE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CE00 */
    { 0x80CF63u, { bank_80_CF63_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CF63 */
    { 0x80D000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80D000 */
    { 0x80D0D5u, { bank_80_D0D5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D0D5 */
    { 0x80D10Eu, { bank_80_D10E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D10E */
    { 0x80D11Au, { bank_80_D11A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D11A */
    { 0x80D12Cu, { bank_80_D12C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D12C */
    { 0x80D15Au, { bank_80_D15A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D15A */
    { 0x80D19Au, { bank_80_D19A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D19A */
    { 0x80D1ABu, { bank_80_D1AB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D1AB */
    { 0x80D21Du, { bank_80_D21D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_D21D */
    { 0x80DE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80DE00 */
    { 0x80DE48u, { bank_80_DE48_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_DE48 */
    { 0x80DE91u, { bank_80_DE91_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_DE91 */
    { 0x80DF35u, { bank_80_DF35_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_DF35 */
    { 0x80DFDEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_DFDE */
    { 0x80E000u, { NULL, NULL, NULL, FR_80E000_M1X1 }, 0 },  /* FR_80E000 */
    { 0x80E218u, { bank_80_E218_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E218 */
    { 0x80E22Cu, { bank_80_E22C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E22C */
    { 0x80E34Cu, { NULL, NULL, NULL, bank_80_E34C_M1X1 }, 0 },  /* bank_80_E34C */
    { 0x80E3E5u, { bank_80_E3E5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E3E5 */
    { 0x80E3E9u, { bank_80_E3E9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E3E9 */
    { 0x80E3FDu, { bank_80_E3FD_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E3FD */
    { 0x80E457u, { bank_80_E457_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E457 */
    { 0x80E47Du, { bank_80_E47D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E47D */
    { 0x80E53Cu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_E53C */
    { 0x80E541u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_E541 */
    { 0x80E549u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_E549 */
    { 0x80E658u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_E658 */
    { 0x80E7FEu, { bank_80_E7FE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E7FE */
    { 0x80E892u, { bank_80_E892_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E892 */
    { 0x80E972u, { bank_80_E972_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E972 */
    { 0x80E98Fu, { bank_80_E98F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E98F */
    { 0x80EA53u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_EA53 */
    { 0x80EA58u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_EA58 */
    { 0x80ECB4u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_ECB4 */
    { 0x80ED06u, { bank_80_ED06_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_ED06 */
    { 0x80F262u, { bank_80_F262_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F262 */
    { 0x80F26Au, { bank_80_F26A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F26A */
    { 0x80F26Eu, { bank_80_F26E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F26E */
    { 0x80F342u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F342 */
    { 0x80F35Du, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F35D */
    { 0x80F362u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F362 */
    { 0x80F36Bu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F36B */
    { 0x80F37Bu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F37B */
    { 0x80F383u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F383 */
    { 0x80F390u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F390 */
    { 0x80F3A1u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3A1 */
    { 0x80F3AEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3AE */
    { 0x80F3B4u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3B4 */
    { 0x80F3BAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3BA */
    { 0x80F3C0u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3C0 */
    { 0x80F3D2u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3D2 */
    { 0x80F3EAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3EA */
    { 0x80F3F8u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F3F8 */
    { 0x80F400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F400 */
    { 0x80F406u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F406 */
    { 0x80F40Cu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F40C */
    { 0x80F41Eu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F41E */
    { 0x80F42Au, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F42A */
    { 0x80F485u, { bank_80_F485_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F485 */
    { 0x80F488u, { bank_80_F488_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F488 */
    { 0x80F495u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F495 */
    { 0x80F4F9u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F4F9 */
    { 0x80F4FCu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F4FC */
    { 0x80F505u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F505 */
    { 0x80F510u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F510 */
    { 0x80F520u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F520 */
    { 0x80F530u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F530 */
    { 0x80F54Bu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F54B */
    { 0x80F596u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F596 */
    { 0x80F5A8u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F5A8 */
    { 0x80F5BAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F5BA */
    { 0x80F5D3u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F5D3 */
    { 0x80F600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F600 */
    { 0x80F644u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F644 */
    { 0x80F653u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F653 */
    { 0x80F660u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F660 */
    { 0x80F678u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F678 */
    { 0x80F6BEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6BE */
    { 0x80F6C7u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6C7 */
    { 0x80F6D3u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6D3 */
    { 0x80F6DFu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6DF */
    { 0x80F6E7u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6E7 */
    { 0x80F6EFu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6EF */
    { 0x80F6F7u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6F7 */
    { 0x80F6FFu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F6FF */
    { 0x80F70Fu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F70F */
    { 0x80F72Cu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F72C */
    { 0x80F73Eu, { bank_80_F73E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F73E */
    { 0x80F744u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F744 */
    { 0x80F753u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F753 */
    { 0x80F76Fu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F76F */
    { 0x80F780u, { bank_80_F780_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F780 */
    { 0x80F786u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F786 */
    { 0x80F795u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F795 */
    { 0x80F7B1u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F7B1 */
    { 0x80F7C2u, { bank_80_F7C2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F7C2 */
    { 0x80F7C8u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F7C8 */
    { 0x80F7D8u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F7D8 */
    { 0x80F7F5u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F7F5 */
    { 0x80F807u, { bank_80_F807_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F807 */
    { 0x80F80Du, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F80D */
    { 0x80F81Cu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F81C */
    { 0x80F838u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F838 */
    { 0x80F849u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F849 */
    { 0x80F858u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F858 */
    { 0x80F874u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F874 */
    { 0x80F885u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F885 */
    { 0x80F889u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F889 */
    { 0x80F895u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F895 */
    { 0x80F89Eu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F89E */
    { 0x80F8AEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F8AE */
    { 0x80F8BBu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F8BB */
    { 0x80F8CCu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F8CC */
    { 0x80F8D9u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_F8D9 */
    { 0x80F8F1u, { bank_80_F8F1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F8F1 */
    { 0x80F91Du, { bank_80_F91D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F91D */
    { 0x80F92Du, { bank_80_F92D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F92D */
    { 0x80FA08u, { bank_80_FA08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FA08 */
    { 0x80FA31u, { CC_80FA31_M0X0, NULL, NULL, CC_80FA31_M1X1 }, 0 },  /* CC_80FA31 */
    { 0x80FA5Cu, { bank_80_FA5C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FA5C */
    { 0x80FA76u, { bank_80_FA76_M0X0, NULL, NULL, bank_80_FA76_M1X1 }, 0 },  /* bank_80_FA76 */
    { 0x80FAA7u, { bank_80_FAA7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FAA7 */
    { 0x80FAF4u, { NULL, NULL, bank_80_FAF4_M1X0, NULL }, 0 },  /* bank_80_FAF4 */
    { 0x80FB03u, { bank_80_FB03_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FB03 */
    { 0x80FD4Au, { bank_80_FD4A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FD4A */
    { 0x80FD99u, { bank_80_FD99_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FD99 */
    { 0x80FE33u, { bank_80_FE33_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FE33 */
    { 0x80FE8Bu, { bank_80_FE8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FE8B */
    { 0x80FF43u, { bank_80_FF43_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FF43 */
    { 0x818000u, { bank_81_8000_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8000 */
    { 0x81801Au, { bank_81_801A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_801A */
    { 0x818076u, { bank_81_8076_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8076 */
    { 0x8183FBu, { bank_81_83FB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_83FB */
    { 0x81840Eu, { bank_81_840E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_840E */
    { 0x8184CFu, { bank_81_84CF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_84CF */
    { 0x8184DEu, { bank_81_84DE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_84DE */
    { 0x8185FEu, { bank_81_85FE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_85FE */
    { 0x818686u, { bank_81_8686_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8686 */
    { 0x8186E5u, { CC_8186E5_M0X0, NULL, NULL, NULL }, 0 },  /* CC_8186E5 */
    { 0x818701u, { bank_81_8701_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8701 */
    { 0x818756u, { bank_81_8756_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8756 */
    { 0x818861u, { bank_81_8861_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8861 */
    { 0x81886Au, { bank_81_886A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_886A */
    { 0x818877u, { bank_81_8877_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8877 */
    { 0x81891Au, { bank_81_891A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_891A */
    { 0x818954u, { bank_81_8954_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8954 */
    { 0x818A05u, { bank_81_8A05_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8A05 */
    { 0x818A91u, { bank_81_8A91_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8A91 */
    { 0x818BD9u, { bank_81_8BD9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8BD9 */
    { 0x818CB9u, { bank_81_8CB9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8CB9 */
    { 0x818CE0u, { bank_81_8CE0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8CE0 */
    { 0x818D05u, { bank_81_8D05_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D05 */
    { 0x818D09u, { bank_81_8D09_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D09 */
    { 0x818D23u, { bank_81_8D23_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D23 */
    { 0x818D3Du, { bank_81_8D3D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D3D */
    { 0x818DC0u, { bank_81_8DC0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8DC0 */
    { 0x818DE2u, { bank_81_8DE2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8DE2 */
    { 0x818E57u, { bank_81_8E57_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8E57 */
    { 0x818EDFu, { bank_81_8EDF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8EDF */
    { 0x818FC2u, { bank_81_8FC2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8FC2 */
    { 0x818FF0u, { bank_81_8FF0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8FF0 */
    { 0x819022u, { bank_81_9022_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9022 */
    { 0x81902Du, { bank_81_902D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_902D */
    { 0x81903Eu, { bank_81_903E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_903E */
    { 0x81940Au, { bank_81_940A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_940A */
    { 0x819490u, { bank_81_9490_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9490 */
    { 0x819AE6u, { bank_81_9AE6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9AE6 */
    { 0x81A117u, { bank_81_A117_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A117 */
    { 0x81A1BCu, { bank_81_A1BC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A1BC */
    { 0x81A1E1u, { bank_81_A1E1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A1E1 */
    { 0x81A243u, { bank_81_A243_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A243 */
    { 0x81A25Fu, { bank_81_A25F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A25F */
    { 0x81A32Du, { bank_81_A32D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A32D */
    { 0x81A344u, { bank_81_A344_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A344 */
    { 0x81A55Cu, { bank_81_A55C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A55C */
    { 0x81A772u, { bank_81_A772_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A772 */
    { 0x81A7FCu, { bank_81_A7FC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A7FC */
    { 0x81A910u, { bank_81_A910_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A910 */
    { 0x81A96Eu, { bank_81_A96E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A96E */
    { 0x81A99Du, { bank_81_A99D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A99D */
    { 0x81AA58u, { bank_81_AA58_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AA58 */
    { 0x81AAE8u, { bank_81_AAE8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AAE8 */
    { 0x81AC6Bu, { bank_81_AC6B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC6B */
    { 0x81AC71u, { bank_81_AC71_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC71 */
    { 0x81AC79u, { bank_81_AC79_M0X0, NULL, NULL, bank_81_AC79_M1X1 }, 0 },  /* bank_81_AC79 */
    { 0x81AC7Fu, { bank_81_AC7F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC7F */
    { 0x81AC85u, { bank_81_AC85_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC85 */
    { 0x81AC8Bu, { bank_81_AC8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC8B */
    { 0x81AD4Eu, { bank_81_AD4E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AD4E */
    { 0x81AD76u, { bank_81_AD76_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AD76 */
    { 0x81ADD0u, { bank_81_ADD0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_ADD0 */
    { 0x81AE08u, { bank_81_AE08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE08 */
    { 0x81AE09u, { bank_81_AE09_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE09 */
    { 0x81AE84u, { bank_81_AE84_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE84 */
    { 0x81AEB0u, { bank_81_AEB0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEB0 */
    { 0x81AEB8u, { bank_81_AEB8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEB8 */
    { 0x81AEC0u, { bank_81_AEC0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEC0 */
    { 0x81AEDBu, { bank_81_AEDB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEDB */
    { 0x81B020u, { bank_81_B020_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B020 */
    { 0x81B05Du, { CC_81B05D_M0X0, NULL, NULL, CC_81B05D_M1X1 }, 0 },  /* CC_81B05D */
    { 0x81B068u, { bank_81_B068_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B068 */
    { 0x81B079u, { bank_81_B079_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B079 */
    { 0x81B0D6u, { bank_81_B0D6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B0D6 */
    { 0x81B0E8u, { bank_81_B0E8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B0E8 */
    { 0x81B130u, { NULL, NULL, bank_81_B130_M1X0, NULL }, 0 },  /* bank_81_B130 */
    { 0x81B167u, { bank_81_B167_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B167 */
    { 0x81D4EEu, { bank_81_D4EE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D4EE */
    { 0x81D512u, { bank_81_D512_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D512 */
    { 0x81D58Du, { NULL, NULL, bank_81_D58D_M1X0, NULL }, 0 },  /* bank_81_D58D */
    { 0x81D5A1u, { NULL, NULL, bank_81_D5A1_M1X0, NULL }, 0 },  /* bank_81_D5A1 */
    { 0x81D5A9u, { NULL, NULL, bank_81_D5A9_M1X0, NULL }, 0 },  /* bank_81_D5A9 */
    { 0x81D5B1u, { NULL, NULL, bank_81_D5B1_M1X0, NULL }, 0 },  /* bank_81_D5B1 */
    { 0x81D5CCu, { bank_81_D5CC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D5CC */
    { 0x81D5FFu, { bank_81_D5FF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D5FF */
    { 0x81D651u, { bank_81_D651_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D651 */
    { 0x81D7DCu, { bank_81_D7DC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D7DC */
    { 0x81D7FBu, { bank_81_D7FB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D7FB */
    { 0x81D839u, { bank_81_D839_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D839 */
    { 0x81D8A2u, { bank_81_D8A2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D8A2 */
    { 0x81D8E4u, { bank_81_D8E4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D8E4 */
    { 0x81DC00u, { bank_81_DC00_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DC00 */
    { 0x81DD6Eu, { bank_81_DD6E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DD6E */
    { 0x81DD9Cu, { bank_81_DD9C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DD9C */
    { 0x81DE54u, { bank_81_DE54_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DE54 */
    { 0x81E10Bu, { bank_81_E10B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E10B */
    { 0x81E260u, { bank_81_E260_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E260 */
    { 0x81E2F0u, { bank_81_E2F0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E2F0 */
    { 0x81E304u, { bank_81_E304_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E304 */
    { 0x81E315u, { bank_81_E315_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E315 */
    { 0x81E332u, { bank_81_E332_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E332 */
    { 0x81E34Eu, { bank_81_E34E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E34E */
    { 0x81E39Bu, { bank_81_E39B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E39B */
    { 0x81E407u, { bank_81_E407_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E407 */
    { 0x81E4CDu, { bank_81_E4CD_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E4CD */
    { 0x81E53Fu, { bank_81_E53F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E53F */
    { 0x81E59Cu, { bank_81_E59C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E59C */
    { 0x81E5E4u, { bank_81_E5E4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E5E4 */
    { 0x81E645u, { bank_81_E645_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E645 */
    { 0x81E65Au, { bank_81_E65A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E65A */
    { 0x81E77Du, { bank_81_E77D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E77D */
    { 0x81E8A6u, { bank_81_E8A6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E8A6 */
    { 0x81EB3Cu, { bank_81_EB3C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EB3C */
    { 0x81EB4Au, { bank_81_EB4A_M0X0, NULL, bank_81_EB4A_M1X0, NULL }, 0 },  /* bank_81_EB4A */
    { 0x81EB58u, { bank_81_EB58_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EB58 */
    { 0x81EBAAu, { bank_81_EBAA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EBAA */
    { 0x81EBD7u, { bank_81_EBD7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EBD7 */
    { 0x81EC02u, { bank_81_EC02_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC02 */
    { 0x81EC03u, { bank_81_EC03_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC03 */
    { 0x81EC10u, { bank_81_EC10_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC10 */
    { 0x81EC29u, { bank_81_EC29_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC29 */
    { 0x81EC78u, { bank_81_EC78_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC78 */
    { 0x81EC8Fu, { bank_81_EC8F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC8F */
    { 0x81EC90u, { bank_81_EC90_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC90 */
    { 0x81EC91u, { bank_81_EC91_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC91 */
    { 0x81ECB3u, { bank_81_ECB3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_ECB3 */
    { 0x81ED4Cu, { NULL, NULL, bank_81_ED4C_M1X0, NULL }, 0 },  /* bank_81_ED4C */
    { 0x81ED77u, { NULL, NULL, bank_81_ED77_M1X0, NULL }, 0 },  /* bank_81_ED77 */
    { 0x81EDE3u, { NULL, NULL, bank_81_EDE3_M1X0, NULL }, 0 },  /* bank_81_EDE3 */
    { 0x81EE10u, { NULL, NULL, bank_81_EE10_M1X0, NULL }, 0 },  /* bank_81_EE10 */
    { 0x81EE7Cu, { bank_81_EE7C_M0X0, NULL, NULL, bank_81_EE7C_M1X1 }, 0 },  /* bank_81_EE7C */
    { 0x81EE96u, { bank_81_EE96_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EE96 */
    { 0x81EE9Eu, { bank_81_EE9E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EE9E */
    { 0x81EEB2u, { bank_81_EEB2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEB2 */
    { 0x81EEC8u, { bank_81_EEC8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEC8 */
    { 0x81EEE7u, { bank_81_EEE7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEE7 */
    { 0x81EEF7u, { bank_81_EEF7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEF7 */
    { 0x81EF08u, { bank_81_EF08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF08 */
    { 0x81EF24u, { bank_81_EF24_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF24 */
    { 0x81EF55u, { bank_81_EF55_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF55 */
    { 0x81EF66u, { NULL, NULL, bank_81_EF66_M1X0, NULL }, 0 },  /* bank_81_EF66 */
    { 0x81EFBBu, { NULL, NULL, bank_81_EFBB_M1X0, NULL }, 0 },  /* bank_81_EFBB */
    { 0x81EFC2u, { NULL, NULL, bank_81_EFC2_M1X0, NULL }, 0 },  /* bank_81_EFC2 */
    { 0x81EFC8u, { bank_81_EFC8_M0X0, NULL, bank_81_EFC8_M1X0, NULL }, 0 },  /* bank_81_EFC8 */
    { 0x81EFFBu, { NULL, NULL, bank_81_EFFB_M1X0, NULL }, 0 },  /* bank_81_EFFB */
    { 0x81F040u, { bank_81_F040_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F040 */
    { 0x81F053u, { bank_81_F053_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F053 */
    { 0x81F0C1u, { bank_81_F0C1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0C1 */
    { 0x81F0E3u, { bank_81_F0E3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0E3 */
    { 0x81F0F1u, { bank_81_F0F1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0F1 */
    { 0x81F1A9u, { bank_81_F1A9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F1A9 */
    { 0x81F1BBu, { NULL, NULL, bank_81_F1BB_M1X0, NULL }, 0 },  /* bank_81_F1BB */
    { 0x81F1EAu, { bank_81_F1EA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F1EA */
    { 0x81F21Bu, { bank_81_F21B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F21B */
    { 0x81F250u, { bank_81_F250_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F250 */
    { 0x81F267u, { bank_81_F267_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F267 */
};

const unsigned g_dispatch_table_count =
    (unsigned)(sizeof(g_dispatch_table) / sizeof(g_dispatch_table[0]));

const RamRoutineGuard g_ram_routine_guards[] = {
    { 0xFFFFFFFFu, 0u, 0u },
};

const unsigned g_ram_routine_guard_count =
    (unsigned)(sizeof(g_ram_routine_guards) / sizeof(g_ram_routine_guards[0]));
