/* Auto-generated from the authoritative LLE/AOT manifest. */
#include "cpu_state.h"

RecompReturn I_RESET_M1X1(CpuState *cpu);
RecompReturn I_IRQ_M0X0(CpuState *cpu);
RecompReturn I_IRQ_M0X1(CpuState *cpu);
RecompReturn I_IRQ_M1X0(CpuState *cpu);
RecompReturn I_IRQ_M1X1(CpuState *cpu);
RecompReturn bank_80_8511_M0X0(CpuState *cpu);
RecompReturn bank_80_8FB3_M0X0(CpuState *cpu);
RecompReturn bank_80_9590_M0X0(CpuState *cpu);
RecompReturn bank_80_95AC_M0X0(CpuState *cpu);
RecompReturn bank_80_986C_M0X0(CpuState *cpu);
RecompReturn bank_80_9D9D_M0X0(CpuState *cpu);
RecompReturn bank_80_9DE8_M0X0(CpuState *cpu);
RecompReturn bank_80_9E01_M0X0(CpuState *cpu);
RecompReturn bank_80_9E1E_M0X0(CpuState *cpu);
RecompReturn bank_80_9ECC_M0X0(CpuState *cpu);
RecompReturn bank_80_9ED0_M0X0(CpuState *cpu);
RecompReturn bank_80_9EEC_M0X0(CpuState *cpu);
RecompReturn bank_80_9EF0_M0X0(CpuState *cpu);
RecompReturn bank_80_A0DF_M0X0(CpuState *cpu);
RecompReturn bank_80_A287_M0X0(CpuState *cpu);
RecompReturn bank_80_A343_M0X0(CpuState *cpu);
RecompReturn bank_80_A3DA_M0X0(CpuState *cpu);
RecompReturn bank_80_A3F1_M0X0(CpuState *cpu);
RecompReturn bank_80_A44C_M0X0(CpuState *cpu);
RecompReturn CC_80A568_M0X0(CpuState *cpu);
RecompReturn bank_80_A586_M0X0(CpuState *cpu);
RecompReturn bank_80_A5A4_M0X0(CpuState *cpu);
RecompReturn bank_80_A7C2_M0X0(CpuState *cpu);
RecompReturn bank_80_A912_M0X0(CpuState *cpu);
RecompReturn bank_80_AA3C_M0X0(CpuState *cpu);
RecompReturn bank_80_AAA9_M1X1(CpuState *cpu);
RecompReturn bank_80_B07F_M1X1(CpuState *cpu);
RecompReturn bank_80_B08A_M1X1(CpuState *cpu);
RecompReturn bank_80_B095_M1X1(CpuState *cpu);
RecompReturn bank_80_B0A0_M1X1(CpuState *cpu);
RecompReturn FR_80B800_M1X1(CpuState *cpu);
RecompReturn bank_80_BA8B_M0X0(CpuState *cpu);
RecompReturn bank_80_BBEA_M0X0(CpuState *cpu);
RecompReturn bank_80_BC82_M0X0(CpuState *cpu);
RecompReturn bank_80_BC8E_M0X0(CpuState *cpu);
RecompReturn CC_80BE2B_M0X0(CpuState *cpu);
RecompReturn bank_80_BE3D_M0X0(CpuState *cpu);
RecompReturn bank_80_C0D9_M0X0(CpuState *cpu);
RecompReturn bank_80_C0D9_M1X0(CpuState *cpu);
RecompReturn CC_80C11F_M0X0(CpuState *cpu);
RecompReturn bank_80_C176_M0X0(CpuState *cpu);
RecompReturn bank_80_C212_M0X0(CpuState *cpu);
RecompReturn bank_80_C298_M0X0(CpuState *cpu);
RecompReturn bank_80_C31A_M0X0(CpuState *cpu);
RecompReturn bank_80_C336_M0X0(CpuState *cpu);
RecompReturn bank_80_C3E6_M0X0(CpuState *cpu);
RecompReturn CC_80C43E_M0X0(CpuState *cpu);
RecompReturn FR_80C800_M1X1(CpuState *cpu);
RecompReturn bank_80_CC14_M0X0(CpuState *cpu);
RecompReturn FR_80E000_M1X1(CpuState *cpu);
RecompReturn bank_80_E218_M0X0(CpuState *cpu);
RecompReturn bank_80_E34C_M1X1(CpuState *cpu);
RecompReturn bank_80_E3E5_M0X0(CpuState *cpu);
RecompReturn bank_80_F262_M0X0(CpuState *cpu);
RecompReturn bank_80_F26A_M0X0(CpuState *cpu);
RecompReturn bank_80_F26E_M0X0(CpuState *cpu);
RecompReturn bank_80_F92D_M0X0(CpuState *cpu);
RecompReturn bank_80_FA08_M0X0(CpuState *cpu);
RecompReturn CC_80FA31_M0X0(CpuState *cpu);
RecompReturn CC_80FA31_M1X1(CpuState *cpu);
RecompReturn bank_80_FA76_M0X0(CpuState *cpu);
RecompReturn bank_80_FA76_M1X1(CpuState *cpu);
RecompReturn bank_80_FAA7_M0X0(CpuState *cpu);
RecompReturn bank_80_FAF4_M1X0(CpuState *cpu);
RecompReturn bank_80_FB03_M0X0(CpuState *cpu);
RecompReturn bank_80_FD4A_M0X0(CpuState *cpu);
RecompReturn bank_80_FE33_M0X0(CpuState *cpu);
RecompReturn bank_80_FE8B_M0X0(CpuState *cpu);
RecompReturn bank_80_FF43_M0X0(CpuState *cpu);
RecompReturn bank_81_8000_M0X0(CpuState *cpu);
RecompReturn bank_81_801A_M0X0(CpuState *cpu);
RecompReturn bank_81_8076_M0X0(CpuState *cpu);
RecompReturn bank_81_83FB_M0X0(CpuState *cpu);
RecompReturn bank_81_840E_M0X0(CpuState *cpu);
RecompReturn bank_81_84CF_M0X0(CpuState *cpu);
RecompReturn bank_81_84DE_M0X0(CpuState *cpu);
RecompReturn bank_81_8701_M0X0(CpuState *cpu);
RecompReturn bank_81_8756_M0X0(CpuState *cpu);
RecompReturn bank_81_8861_M0X0(CpuState *cpu);
RecompReturn bank_81_8877_M0X0(CpuState *cpu);
RecompReturn bank_81_891A_M0X0(CpuState *cpu);
RecompReturn bank_81_8954_M0X0(CpuState *cpu);
RecompReturn bank_81_8A05_M0X0(CpuState *cpu);
RecompReturn bank_81_8A91_M0X0(CpuState *cpu);
RecompReturn bank_81_8BD9_M0X0(CpuState *cpu);
RecompReturn bank_81_8CB9_M0X0(CpuState *cpu);
RecompReturn bank_81_8CE0_M0X0(CpuState *cpu);
RecompReturn bank_81_8D05_M0X0(CpuState *cpu);
RecompReturn bank_81_8D09_M0X0(CpuState *cpu);
RecompReturn bank_81_8D23_M0X0(CpuState *cpu);
RecompReturn bank_81_8D3D_M0X0(CpuState *cpu);
RecompReturn bank_81_8DC0_M0X0(CpuState *cpu);
RecompReturn bank_81_8DE2_M0X0(CpuState *cpu);
RecompReturn bank_81_8E57_M0X0(CpuState *cpu);
RecompReturn bank_81_8EDF_M0X0(CpuState *cpu);
RecompReturn bank_81_8FC2_M0X0(CpuState *cpu);
RecompReturn bank_81_8FF0_M0X0(CpuState *cpu);
RecompReturn bank_81_9022_M0X0(CpuState *cpu);
RecompReturn bank_81_902D_M0X0(CpuState *cpu);
RecompReturn bank_81_903E_M0X0(CpuState *cpu);
RecompReturn bank_81_940A_M0X0(CpuState *cpu);
RecompReturn bank_81_9490_M0X0(CpuState *cpu);
RecompReturn bank_81_9AE6_M0X0(CpuState *cpu);
RecompReturn bank_81_A117_M0X0(CpuState *cpu);
RecompReturn bank_81_A1BC_M0X0(CpuState *cpu);
RecompReturn bank_81_A1E1_M0X0(CpuState *cpu);
RecompReturn bank_81_A243_M0X0(CpuState *cpu);
RecompReturn bank_81_A772_M0X0(CpuState *cpu);
RecompReturn bank_81_A7FC_M0X0(CpuState *cpu);
RecompReturn bank_81_A96E_M0X0(CpuState *cpu);
RecompReturn bank_81_A99D_M0X0(CpuState *cpu);
RecompReturn bank_81_AA58_M0X0(CpuState *cpu);
RecompReturn bank_81_AAE8_M0X0(CpuState *cpu);
RecompReturn bank_81_AC6B_M0X0(CpuState *cpu);
RecompReturn bank_81_AC71_M0X0(CpuState *cpu);
RecompReturn bank_81_AC79_M0X0(CpuState *cpu);
RecompReturn bank_81_AC79_M1X1(CpuState *cpu);
RecompReturn bank_81_AC7F_M0X0(CpuState *cpu);
RecompReturn bank_81_AC85_M0X0(CpuState *cpu);
RecompReturn bank_81_AC8B_M0X0(CpuState *cpu);
RecompReturn bank_81_AD4E_M0X0(CpuState *cpu);
RecompReturn bank_81_AD76_M0X0(CpuState *cpu);
RecompReturn bank_81_ADD0_M0X0(CpuState *cpu);
RecompReturn bank_81_AE08_M0X0(CpuState *cpu);
RecompReturn bank_81_AE09_M0X0(CpuState *cpu);
RecompReturn bank_81_AE84_M0X0(CpuState *cpu);
RecompReturn bank_81_AEB0_M0X0(CpuState *cpu);
RecompReturn bank_81_AEB8_M0X0(CpuState *cpu);
RecompReturn bank_81_AEC0_M0X0(CpuState *cpu);
RecompReturn bank_81_AEDB_M0X0(CpuState *cpu);
RecompReturn bank_81_B020_M0X0(CpuState *cpu);
RecompReturn CC_81B05D_M0X0(CpuState *cpu);
RecompReturn CC_81B05D_M1X1(CpuState *cpu);
RecompReturn bank_81_B068_M0X0(CpuState *cpu);
RecompReturn bank_81_B079_M0X0(CpuState *cpu);
RecompReturn bank_81_B0D6_M0X0(CpuState *cpu);
RecompReturn bank_81_B0E8_M0X0(CpuState *cpu);
RecompReturn bank_81_B130_M1X0(CpuState *cpu);
RecompReturn bank_81_B167_M0X0(CpuState *cpu);
RecompReturn bank_81_D4EE_M0X0(CpuState *cpu);
RecompReturn bank_81_D512_M0X0(CpuState *cpu);
RecompReturn bank_81_D58D_M1X0(CpuState *cpu);
RecompReturn bank_81_D5A1_M1X0(CpuState *cpu);
RecompReturn bank_81_D5A9_M1X0(CpuState *cpu);
RecompReturn bank_81_D5B1_M1X0(CpuState *cpu);
RecompReturn bank_81_D5CC_M0X0(CpuState *cpu);
RecompReturn bank_81_D5FF_M0X0(CpuState *cpu);
RecompReturn bank_81_D651_M0X0(CpuState *cpu);
RecompReturn bank_81_D7DC_M0X0(CpuState *cpu);
RecompReturn bank_81_D7FB_M0X0(CpuState *cpu);
RecompReturn bank_81_D839_M0X0(CpuState *cpu);
RecompReturn bank_81_D8A2_M0X0(CpuState *cpu);
RecompReturn bank_81_D8E4_M0X0(CpuState *cpu);
RecompReturn bank_81_DC00_M0X0(CpuState *cpu);
RecompReturn bank_81_DD6E_M0X0(CpuState *cpu);
RecompReturn bank_81_DD9C_M0X0(CpuState *cpu);
RecompReturn bank_81_DE54_M0X0(CpuState *cpu);
RecompReturn bank_81_E10B_M0X0(CpuState *cpu);
RecompReturn bank_81_E260_M0X0(CpuState *cpu);
RecompReturn bank_81_E2F0_M0X0(CpuState *cpu);
RecompReturn bank_81_E304_M0X0(CpuState *cpu);
RecompReturn bank_81_E315_M0X0(CpuState *cpu);
RecompReturn bank_81_E332_M0X0(CpuState *cpu);
RecompReturn bank_81_E34E_M0X0(CpuState *cpu);
RecompReturn bank_81_E39B_M0X0(CpuState *cpu);
RecompReturn bank_81_E407_M0X0(CpuState *cpu);
RecompReturn bank_81_E4CD_M0X0(CpuState *cpu);
RecompReturn bank_81_E53F_M0X0(CpuState *cpu);
RecompReturn bank_81_E59C_M0X0(CpuState *cpu);
RecompReturn bank_81_E5E4_M0X0(CpuState *cpu);
RecompReturn bank_81_E645_M0X0(CpuState *cpu);
RecompReturn bank_81_E65A_M0X0(CpuState *cpu);
RecompReturn bank_81_E77D_M0X0(CpuState *cpu);
RecompReturn bank_81_E8A6_M0X0(CpuState *cpu);
RecompReturn bank_81_EB3C_M0X0(CpuState *cpu);
RecompReturn bank_81_EB4A_M0X0(CpuState *cpu);
RecompReturn bank_81_EB4A_M1X0(CpuState *cpu);
RecompReturn bank_81_EB58_M0X0(CpuState *cpu);
RecompReturn bank_81_EBAA_M0X0(CpuState *cpu);
RecompReturn bank_81_EBD7_M0X0(CpuState *cpu);
RecompReturn bank_81_EC02_M0X0(CpuState *cpu);
RecompReturn bank_81_EC03_M0X0(CpuState *cpu);
RecompReturn bank_81_EC10_M0X0(CpuState *cpu);
RecompReturn bank_81_EC29_M0X0(CpuState *cpu);
RecompReturn bank_81_EC78_M0X0(CpuState *cpu);
RecompReturn bank_81_EC8F_M0X0(CpuState *cpu);
RecompReturn bank_81_EC90_M0X0(CpuState *cpu);
RecompReturn bank_81_EC91_M0X0(CpuState *cpu);
RecompReturn bank_81_ECB3_M0X0(CpuState *cpu);
RecompReturn bank_81_ED4C_M1X0(CpuState *cpu);
RecompReturn bank_81_ED77_M1X0(CpuState *cpu);
RecompReturn bank_81_EDE3_M1X0(CpuState *cpu);
RecompReturn bank_81_EE10_M1X0(CpuState *cpu);
RecompReturn bank_81_EE7C_M0X0(CpuState *cpu);
RecompReturn bank_81_EE7C_M1X1(CpuState *cpu);
RecompReturn bank_81_EE96_M0X0(CpuState *cpu);
RecompReturn bank_81_EE9E_M0X0(CpuState *cpu);
RecompReturn bank_81_EEB2_M0X0(CpuState *cpu);
RecompReturn bank_81_EEC8_M0X0(CpuState *cpu);
RecompReturn bank_81_EEE7_M0X0(CpuState *cpu);
RecompReturn bank_81_EEF7_M0X0(CpuState *cpu);
RecompReturn bank_81_EF08_M0X0(CpuState *cpu);
RecompReturn bank_81_EF24_M0X0(CpuState *cpu);
RecompReturn bank_81_EF55_M0X0(CpuState *cpu);
RecompReturn bank_81_EF66_M1X0(CpuState *cpu);
RecompReturn bank_81_EFBB_M1X0(CpuState *cpu);
RecompReturn bank_81_EFC2_M1X0(CpuState *cpu);
RecompReturn bank_81_EFC8_M0X0(CpuState *cpu);
RecompReturn bank_81_EFC8_M1X0(CpuState *cpu);
RecompReturn bank_81_EFFB_M1X0(CpuState *cpu);
RecompReturn bank_81_F040_M0X0(CpuState *cpu);
RecompReturn bank_81_F053_M0X0(CpuState *cpu);
RecompReturn bank_81_F0C1_M0X0(CpuState *cpu);
RecompReturn bank_81_F0E3_M0X0(CpuState *cpu);
RecompReturn bank_81_F0F1_M0X0(CpuState *cpu);
RecompReturn bank_81_F1A9_M0X0(CpuState *cpu);
RecompReturn bank_81_F1BB_M1X0(CpuState *cpu);
RecompReturn bank_81_F1EA_M0X0(CpuState *cpu);
RecompReturn bank_81_F21B_M0X0(CpuState *cpu);
RecompReturn bank_81_F250_M0X0(CpuState *cpu);
RecompReturn bank_81_F267_M0X0(CpuState *cpu);

const DispatchEntry g_dispatch_table[] = {
    { 0x00C0E2u, { NULL, NULL, NULL, NULL }, 0 },  /* I_NMI */
    { 0x00E34Cu, { NULL, NULL, NULL, I_RESET_M1X1 }, 0 },  /* I_RESET */
    { 0x00F27Du, { I_IRQ_M0X0, I_IRQ_M0X1, I_IRQ_M1X0, I_IRQ_M1X1 }, 0 },  /* I_IRQ */
    { 0x808000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808000 */
    { 0x808200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808200 */
    { 0x808511u, { bank_80_8511_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8511 */
    { 0x808600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808600 */
    { 0x808800u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808800 */
    { 0x808A00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808A00 */
    { 0x808FAAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8FAA */
    { 0x808FB3u, { bank_80_8FB3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_8FB3 */
    { 0x809000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809000 */
    { 0x809200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809200 */
    { 0x809590u, { bank_80_9590_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9590 */
    { 0x8095ACu, { bank_80_95AC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_95AC */
    { 0x80961Cu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80961C */
    { 0x809676u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_809676 */
    { 0x80986Cu, { bank_80_986C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_986C */
    { 0x80996Eu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80996E */
    { 0x809D9Du, { bank_80_9D9D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9D9D */
    { 0x809DE8u, { bank_80_9DE8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9DE8 */
    { 0x809E01u, { bank_80_9E01_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9E01 */
    { 0x809E1Eu, { bank_80_9E1E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9E1E */
    { 0x809ECCu, { bank_80_9ECC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9ECC */
    { 0x809ED0u, { bank_80_9ED0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9ED0 */
    { 0x809EECu, { bank_80_9EEC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9EEC */
    { 0x809EF0u, { bank_80_9EF0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_9EF0 */
    { 0x80A0B6u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_A0B6 */
    { 0x80A0DFu, { bank_80_A0DF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A0DF */
    { 0x80A0EBu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A0EB */
    { 0x80A113u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A113 */
    { 0x80A287u, { bank_80_A287_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A287 */
    { 0x80A343u, { bank_80_A343_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A343 */
    { 0x80A3DAu, { bank_80_A3DA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A3DA */
    { 0x80A3F1u, { bank_80_A3F1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A3F1 */
    { 0x80A44Cu, { bank_80_A44C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A44C */
    { 0x80A568u, { CC_80A568_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80A568 */
    { 0x80A586u, { bank_80_A586_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A586 */
    { 0x80A5A4u, { bank_80_A5A4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A5A4 */
    { 0x80A632u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80A632 */
    { 0x80A7C2u, { bank_80_A7C2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A7C2 */
    { 0x80A912u, { bank_80_A912_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_A912 */
    { 0x80AA3Cu, { bank_80_AA3C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_AA3C */
    { 0x80AAA9u, { NULL, NULL, NULL, bank_80_AAA9_M1X1 }, 0 },  /* bank_80_AAA9 */
    { 0x80AC00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AC00 */
    { 0x80AE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AE00 */
    { 0x80B000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B000 */
    { 0x80B032u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B032 */
    { 0x80B07Au, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80B07A */
    { 0x80B07Fu, { NULL, NULL, NULL, bank_80_B07F_M1X1 }, 0 },  /* bank_80_B07F */
    { 0x80B08Au, { NULL, NULL, NULL, bank_80_B08A_M1X1 }, 0 },  /* bank_80_B08A */
    { 0x80B095u, { NULL, NULL, NULL, bank_80_B095_M1X1 }, 0 },  /* bank_80_B095 */
    { 0x80B0A0u, { NULL, NULL, NULL, bank_80_B0A0_M1X1 }, 0 },  /* bank_80_B0A0 */
    { 0x80B101u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B101 */
    { 0x80B200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B200 */
    { 0x80B400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B400 */
    { 0x80B600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B600 */
    { 0x80B800u, { NULL, NULL, NULL, FR_80B800_M1X1 }, 0 },  /* FR_80B800 */
    { 0x80BA8Bu, { bank_80_BA8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BA8B */
    { 0x80BBEAu, { bank_80_BBEA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BBEA */
    { 0x80BC82u, { bank_80_BC82_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC82 */
    { 0x80BC8Eu, { bank_80_BC8E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BC8E */
    { 0x80BE2Bu, { CC_80BE2B_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80BE2B */
    { 0x80BE3Du, { bank_80_BE3D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_BE3D */
    { 0x80BF0Bu, { NULL, NULL, NULL, NULL }, 0 },  /* CC_80BF0B */
    { 0x80C0D9u, { bank_80_C0D9_M0X0, NULL, bank_80_C0D9_M1X0, NULL }, 0 },  /* bank_80_C0D9 */
    { 0x80C11Fu, { CC_80C11F_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80C11F */
    { 0x80C176u, { bank_80_C176_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C176 */
    { 0x80C212u, { bank_80_C212_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C212 */
    { 0x80C298u, { bank_80_C298_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C298 */
    { 0x80C31Au, { bank_80_C31A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C31A */
    { 0x80C336u, { bank_80_C336_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C336 */
    { 0x80C3E6u, { bank_80_C3E6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_C3E6 */
    { 0x80C43Eu, { CC_80C43E_M0X0, NULL, NULL, NULL }, 0 },  /* CC_80C43E */
    { 0x80C600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80C600 */
    { 0x80C800u, { NULL, NULL, NULL, FR_80C800_M1X1 }, 0 },  /* FR_80C800 */
    { 0x80CA00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CA00 */
    { 0x80CC14u, { bank_80_CC14_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_CC14 */
    { 0x80CE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CE00 */
    { 0x80D000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80D000 */
    { 0x80DE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80DE00 */
    { 0x80E000u, { NULL, NULL, NULL, FR_80E000_M1X1 }, 0 },  /* FR_80E000 */
    { 0x80E218u, { bank_80_E218_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E218 */
    { 0x80E34Cu, { NULL, NULL, NULL, bank_80_E34C_M1X1 }, 0 },  /* bank_80_E34C */
    { 0x80E3E5u, { bank_80_E3E5_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_E3E5 */
    { 0x80F262u, { bank_80_F262_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F262 */
    { 0x80F26Au, { bank_80_F26A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F26A */
    { 0x80F26Eu, { bank_80_F26E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F26E */
    { 0x80F400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F400 */
    { 0x80F600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F600 */
    { 0x80F92Du, { bank_80_F92D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_F92D */
    { 0x80FA08u, { bank_80_FA08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FA08 */
    { 0x80FA31u, { CC_80FA31_M0X0, NULL, NULL, CC_80FA31_M1X1 }, 0 },  /* CC_80FA31 */
    { 0x80FA76u, { bank_80_FA76_M0X0, NULL, NULL, bank_80_FA76_M1X1 }, 0 },  /* bank_80_FA76 */
    { 0x80FAA7u, { bank_80_FAA7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FAA7 */
    { 0x80FAF4u, { NULL, NULL, bank_80_FAF4_M1X0, NULL }, 0 },  /* bank_80_FAF4 */
    { 0x80FB03u, { bank_80_FB03_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FB03 */
    { 0x80FD4Au, { bank_80_FD4A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FD4A */
    { 0x80FE33u, { bank_80_FE33_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FE33 */
    { 0x80FE8Bu, { bank_80_FE8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FE8B */
    { 0x80FF43u, { bank_80_FF43_M0X0, NULL, NULL, NULL }, 0 },  /* bank_80_FF43 */
    { 0x818000u, { bank_81_8000_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8000 */
    { 0x81801Au, { bank_81_801A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_801A */
    { 0x818076u, { bank_81_8076_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8076 */
    { 0x8183FBu, { bank_81_83FB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_83FB */
    { 0x81840Eu, { bank_81_840E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_840E */
    { 0x8184CFu, { bank_81_84CF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_84CF */
    { 0x8184DEu, { bank_81_84DE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_84DE */
    { 0x8185FEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_81_85FE */
    { 0x818686u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_81_8686 */
    { 0x8186E5u, { NULL, NULL, NULL, NULL }, 0 },  /* CC_8186E5 */
    { 0x818701u, { bank_81_8701_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8701 */
    { 0x818756u, { bank_81_8756_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8756 */
    { 0x818861u, { bank_81_8861_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8861 */
    { 0x818877u, { bank_81_8877_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8877 */
    { 0x81891Au, { bank_81_891A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_891A */
    { 0x818954u, { bank_81_8954_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8954 */
    { 0x818A05u, { bank_81_8A05_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8A05 */
    { 0x818A91u, { bank_81_8A91_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8A91 */
    { 0x818BD9u, { bank_81_8BD9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8BD9 */
    { 0x818CB9u, { bank_81_8CB9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8CB9 */
    { 0x818CE0u, { bank_81_8CE0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8CE0 */
    { 0x818D05u, { bank_81_8D05_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D05 */
    { 0x818D09u, { bank_81_8D09_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D09 */
    { 0x818D23u, { bank_81_8D23_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D23 */
    { 0x818D3Du, { bank_81_8D3D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8D3D */
    { 0x818DC0u, { bank_81_8DC0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8DC0 */
    { 0x818DE2u, { bank_81_8DE2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8DE2 */
    { 0x818E57u, { bank_81_8E57_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8E57 */
    { 0x818EDFu, { bank_81_8EDF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8EDF */
    { 0x818FC2u, { bank_81_8FC2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8FC2 */
    { 0x818FF0u, { bank_81_8FF0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_8FF0 */
    { 0x819022u, { bank_81_9022_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9022 */
    { 0x81902Du, { bank_81_902D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_902D */
    { 0x81903Eu, { bank_81_903E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_903E */
    { 0x81940Au, { bank_81_940A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_940A */
    { 0x819490u, { bank_81_9490_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9490 */
    { 0x819AE6u, { bank_81_9AE6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_9AE6 */
    { 0x81A117u, { bank_81_A117_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A117 */
    { 0x81A1BCu, { bank_81_A1BC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A1BC */
    { 0x81A1E1u, { bank_81_A1E1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A1E1 */
    { 0x81A243u, { bank_81_A243_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A243 */
    { 0x81A772u, { bank_81_A772_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A772 */
    { 0x81A7FCu, { bank_81_A7FC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A7FC */
    { 0x81A96Eu, { bank_81_A96E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A96E */
    { 0x81A99Du, { bank_81_A99D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_A99D */
    { 0x81AA58u, { bank_81_AA58_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AA58 */
    { 0x81AAE8u, { bank_81_AAE8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AAE8 */
    { 0x81AC6Bu, { bank_81_AC6B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC6B */
    { 0x81AC71u, { bank_81_AC71_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC71 */
    { 0x81AC79u, { bank_81_AC79_M0X0, NULL, NULL, bank_81_AC79_M1X1 }, 0 },  /* bank_81_AC79 */
    { 0x81AC7Fu, { bank_81_AC7F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC7F */
    { 0x81AC85u, { bank_81_AC85_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC85 */
    { 0x81AC8Bu, { bank_81_AC8B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AC8B */
    { 0x81AD4Eu, { bank_81_AD4E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AD4E */
    { 0x81AD76u, { bank_81_AD76_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AD76 */
    { 0x81ADD0u, { bank_81_ADD0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_ADD0 */
    { 0x81AE08u, { bank_81_AE08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE08 */
    { 0x81AE09u, { bank_81_AE09_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE09 */
    { 0x81AE84u, { bank_81_AE84_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AE84 */
    { 0x81AEB0u, { bank_81_AEB0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEB0 */
    { 0x81AEB8u, { bank_81_AEB8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEB8 */
    { 0x81AEC0u, { bank_81_AEC0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEC0 */
    { 0x81AEDBu, { bank_81_AEDB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_AEDB */
    { 0x81B020u, { bank_81_B020_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B020 */
    { 0x81B05Du, { CC_81B05D_M0X0, NULL, NULL, CC_81B05D_M1X1 }, 0 },  /* CC_81B05D */
    { 0x81B068u, { bank_81_B068_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B068 */
    { 0x81B079u, { bank_81_B079_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B079 */
    { 0x81B0D6u, { bank_81_B0D6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B0D6 */
    { 0x81B0E8u, { bank_81_B0E8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B0E8 */
    { 0x81B130u, { NULL, NULL, bank_81_B130_M1X0, NULL }, 0 },  /* bank_81_B130 */
    { 0x81B167u, { bank_81_B167_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_B167 */
    { 0x81D4EEu, { bank_81_D4EE_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D4EE */
    { 0x81D512u, { bank_81_D512_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D512 */
    { 0x81D58Du, { NULL, NULL, bank_81_D58D_M1X0, NULL }, 0 },  /* bank_81_D58D */
    { 0x81D5A1u, { NULL, NULL, bank_81_D5A1_M1X0, NULL }, 0 },  /* bank_81_D5A1 */
    { 0x81D5A9u, { NULL, NULL, bank_81_D5A9_M1X0, NULL }, 0 },  /* bank_81_D5A9 */
    { 0x81D5B1u, { NULL, NULL, bank_81_D5B1_M1X0, NULL }, 0 },  /* bank_81_D5B1 */
    { 0x81D5CCu, { bank_81_D5CC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D5CC */
    { 0x81D5FFu, { bank_81_D5FF_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D5FF */
    { 0x81D651u, { bank_81_D651_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D651 */
    { 0x81D7DCu, { bank_81_D7DC_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D7DC */
    { 0x81D7FBu, { bank_81_D7FB_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D7FB */
    { 0x81D839u, { bank_81_D839_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D839 */
    { 0x81D8A2u, { bank_81_D8A2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D8A2 */
    { 0x81D8E4u, { bank_81_D8E4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_D8E4 */
    { 0x81DC00u, { bank_81_DC00_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DC00 */
    { 0x81DD6Eu, { bank_81_DD6E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DD6E */
    { 0x81DD9Cu, { bank_81_DD9C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DD9C */
    { 0x81DE54u, { bank_81_DE54_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_DE54 */
    { 0x81E10Bu, { bank_81_E10B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E10B */
    { 0x81E260u, { bank_81_E260_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E260 */
    { 0x81E2F0u, { bank_81_E2F0_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E2F0 */
    { 0x81E304u, { bank_81_E304_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E304 */
    { 0x81E315u, { bank_81_E315_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E315 */
    { 0x81E332u, { bank_81_E332_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E332 */
    { 0x81E34Eu, { bank_81_E34E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E34E */
    { 0x81E39Bu, { bank_81_E39B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E39B */
    { 0x81E407u, { bank_81_E407_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E407 */
    { 0x81E4CDu, { bank_81_E4CD_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E4CD */
    { 0x81E53Fu, { bank_81_E53F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E53F */
    { 0x81E59Cu, { bank_81_E59C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E59C */
    { 0x81E5E4u, { bank_81_E5E4_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E5E4 */
    { 0x81E645u, { bank_81_E645_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E645 */
    { 0x81E65Au, { bank_81_E65A_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E65A */
    { 0x81E77Du, { bank_81_E77D_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E77D */
    { 0x81E8A6u, { bank_81_E8A6_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_E8A6 */
    { 0x81EB3Cu, { bank_81_EB3C_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EB3C */
    { 0x81EB4Au, { bank_81_EB4A_M0X0, NULL, bank_81_EB4A_M1X0, NULL }, 0 },  /* bank_81_EB4A */
    { 0x81EB58u, { bank_81_EB58_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EB58 */
    { 0x81EBAAu, { bank_81_EBAA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EBAA */
    { 0x81EBD7u, { bank_81_EBD7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EBD7 */
    { 0x81EC02u, { bank_81_EC02_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC02 */
    { 0x81EC03u, { bank_81_EC03_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC03 */
    { 0x81EC10u, { bank_81_EC10_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC10 */
    { 0x81EC29u, { bank_81_EC29_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC29 */
    { 0x81EC78u, { bank_81_EC78_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC78 */
    { 0x81EC8Fu, { bank_81_EC8F_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC8F */
    { 0x81EC90u, { bank_81_EC90_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC90 */
    { 0x81EC91u, { bank_81_EC91_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EC91 */
    { 0x81ECB3u, { bank_81_ECB3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_ECB3 */
    { 0x81ED4Cu, { NULL, NULL, bank_81_ED4C_M1X0, NULL }, 0 },  /* bank_81_ED4C */
    { 0x81ED77u, { NULL, NULL, bank_81_ED77_M1X0, NULL }, 0 },  /* bank_81_ED77 */
    { 0x81EDE3u, { NULL, NULL, bank_81_EDE3_M1X0, NULL }, 0 },  /* bank_81_EDE3 */
    { 0x81EE10u, { NULL, NULL, bank_81_EE10_M1X0, NULL }, 0 },  /* bank_81_EE10 */
    { 0x81EE7Cu, { bank_81_EE7C_M0X0, NULL, NULL, bank_81_EE7C_M1X1 }, 0 },  /* bank_81_EE7C */
    { 0x81EE96u, { bank_81_EE96_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EE96 */
    { 0x81EE9Eu, { bank_81_EE9E_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EE9E */
    { 0x81EEB2u, { bank_81_EEB2_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEB2 */
    { 0x81EEC8u, { bank_81_EEC8_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEC8 */
    { 0x81EEE7u, { bank_81_EEE7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEE7 */
    { 0x81EEF7u, { bank_81_EEF7_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EEF7 */
    { 0x81EF08u, { bank_81_EF08_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF08 */
    { 0x81EF24u, { bank_81_EF24_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF24 */
    { 0x81EF55u, { bank_81_EF55_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_EF55 */
    { 0x81EF66u, { NULL, NULL, bank_81_EF66_M1X0, NULL }, 0 },  /* bank_81_EF66 */
    { 0x81EFBBu, { NULL, NULL, bank_81_EFBB_M1X0, NULL }, 0 },  /* bank_81_EFBB */
    { 0x81EFC2u, { NULL, NULL, bank_81_EFC2_M1X0, NULL }, 0 },  /* bank_81_EFC2 */
    { 0x81EFC8u, { bank_81_EFC8_M0X0, NULL, bank_81_EFC8_M1X0, NULL }, 0 },  /* bank_81_EFC8 */
    { 0x81EFFBu, { NULL, NULL, bank_81_EFFB_M1X0, NULL }, 0 },  /* bank_81_EFFB */
    { 0x81F040u, { bank_81_F040_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F040 */
    { 0x81F053u, { bank_81_F053_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F053 */
    { 0x81F0C1u, { bank_81_F0C1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0C1 */
    { 0x81F0E3u, { bank_81_F0E3_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0E3 */
    { 0x81F0F1u, { bank_81_F0F1_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F0F1 */
    { 0x81F1A9u, { bank_81_F1A9_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F1A9 */
    { 0x81F1BBu, { NULL, NULL, bank_81_F1BB_M1X0, NULL }, 0 },  /* bank_81_F1BB */
    { 0x81F1EAu, { bank_81_F1EA_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F1EA */
    { 0x81F21Bu, { bank_81_F21B_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F21B */
    { 0x81F250u, { bank_81_F250_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F250 */
    { 0x81F267u, { bank_81_F267_M0X0, NULL, NULL, NULL }, 0 },  /* bank_81_F267 */
};

const unsigned g_dispatch_table_count =
    (unsigned)(sizeof(g_dispatch_table) / sizeof(g_dispatch_table[0]));

const RamRoutineGuard g_ram_routine_guards[] = {
    { 0xFFFFFFFFu, 0u, 0u },
};

const unsigned g_ram_routine_guard_count =
    (unsigned)(sizeof(g_ram_routine_guards) / sizeof(g_ram_routine_guards[0]));
