/* Auto-generated from the authoritative LLE/AOT manifest. */
#include "cpu_state.h"


const DispatchEntry g_dispatch_table[] = {
    { 0x00C0E2u, { NULL, NULL, NULL, NULL }, 0 },  /* I_NMI */
    { 0x808000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808000 */
    { 0x808200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808200 */
    { 0x808600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808600 */
    { 0x808800u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808800 */
    { 0x808A00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_808A00 */
    { 0x808FAAu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_8FAA */
    { 0x809000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809000 */
    { 0x809200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_809200 */
    { 0x80AC00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AC00 */
    { 0x80AE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80AE00 */
    { 0x80B000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B000 */
    { 0x80B032u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B032 */
    { 0x80B07Au, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B07A */
    { 0x80B101u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_80_B101 */
    { 0x80B200u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B200 */
    { 0x80B400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B400 */
    { 0x80B600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80B600 */
    { 0x80C600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80C600 */
    { 0x80CA00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CA00 */
    { 0x80CE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80CE00 */
    { 0x80D000u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80D000 */
    { 0x80DE00u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80DE00 */
    { 0x80F400u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F400 */
    { 0x80F600u, { NULL, NULL, NULL, NULL }, 0 },  /* FR_80F600 */
    { 0x8185FEu, { NULL, NULL, NULL, NULL }, 0 },  /* bank_81_85FE */
    { 0x818686u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_81_8686 */
    { 0x8186E5u, { NULL, NULL, NULL, NULL }, 0 },  /* bank_81_86E5 */
};

const unsigned g_dispatch_table_count =
    (unsigned)(sizeof(g_dispatch_table) / sizeof(g_dispatch_table[0]));

const RamRoutineGuard g_ram_routine_guards[] = {
    { 0xFFFFFFFFu, 0u, 0u },
};

const unsigned g_ram_routine_guard_count =
    (unsigned)(sizeof(g_ram_routine_guards) / sizeof(g_ram_routine_guards[0]));
